﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    class Program
    {
        static void Main(string[] args)
        {
           // List<MathOperations> mathOperationses =new List<MathOperations>();
            MathOperations mo = new MathOperations();
            Console.WriteLine(mo.Add(2, 3));
            Console.WriteLine(mo.Add(2.2, 3.3, 5.5));
            Console.WriteLine(mo.Add(2.2m, 3.3m, 4.4m));

        }
    }

    class MathOperations
    {
        public int Add(int numOne, int numTwo)
        {
            return numOne + numTwo;
        }
        public double Add(double numOne, double numTwo,double c)
        {
            return numOne + numTwo+c;
        }
        public decimal Add(decimal numOne, decimal numTwo,decimal c)
        {
            return  (numOne + numTwo+c);
        }
    }

