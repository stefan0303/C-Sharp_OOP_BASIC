﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
public class Team
{
    private string name; //Name of the team
    private List<Player> players; //Players of the team

    public Team(string name)
    {
        this.Name = name;
        this.players = new List<Player>();
    }
    public string Name
    {
        get
        {
            return this.name;
        }
        set
        {
            if (string.IsNullOrEmpty(value) || string.IsNullOrWhiteSpace(value))
            {
                throw new ArgumentException("A name should not be empty.");
            }
            this.name = value;
        }
    }
    public int Rating() //namirame ratinga na otbora
    {
        if (players.Count == 0)
        {
            return 0;
        }
        //Selectirame vsichki igrachi ot Listata vadim na vseki igrach averageStats(Funkcia v Players) i delim na broia na igrachite
        return (int)Math.Round(this.players.Select(p => p.AveraStatsfPlayer()).Sum() / (double)this.players.Count);
    }
    public void AddPlayers(Player player) //Advame player kum otbora
    {
        players.Add(player);
    }
    public void RemovePlayer(string team, string playerName)
    {

        bool containsPlayer = this.players.Any(p => p.Name == playerName);

        if (!containsPlayer)
        {
            string message = $"Player {playerName} is not in {team} team.";
            throw new ArgumentException(message);


        }
       
            Player player = players.FirstOrDefault(p => p.Name == playerName);
            players.Remove(player);
    }
}

public class Player
{
    private string name;
    private int endurance;
    private int spirit;
    private int dribble;
    private int passing;
    private int shooting;

    //Constructor
    public Player(string name, int endurance, int spirit, int dribble, int passing, int shooting)
    {
        this.Name = name;
        this.Endurance = endurance;
        this.Spirit = spirit;
        this.Dribble = dribble;
        this.Passing = passing;
        this.Shooting = shooting;
    }
    public string Name //catch Exeptions 
    {
        get //vrushta
        {
            return this.name;
        }
        set //setvame go i hvashtame eventulen losh imput
        {
            if (string.IsNullOrWhiteSpace(value) || string.IsNullOrEmpty(value))
            {
                throw new ArgumentException("A name should not be empty.");

            }

            this.name = value;


        }
    }
    public int Endurance
    {
        get
        {
            return this.endurance;
        }
       private set
        {
            if (value < 0 || value > 100)
            {
                throw new ArgumentException("Endurance should be between 0 and 100.");


            }
            this.endurance = value;
        }

    }
    public int Spirit
    {
        get
        {
            return this.spirit;
        }
      private  set
        {
            if (value < 0 || value > 100)
            {
                throw new ArgumentException("Sprint should be between 0 and 100.");

            }
            else
            {
                this.spirit = value;
            }

        }
    }
    public int Dribble
    {
        get
        {

            return this.dribble;
        }
    private    set
        {
            if (value < 0 || value > 100)
            {
                throw new ArgumentException("Dribble should be between 0 and 100.");

            }
            else
            {
                this.dribble = value;
            }

        }
    }
    public int Passing
    {
        get
        {

            return this.passing;
        }
   private     set
        {
            if (value < 0 || value > 100)
            {
                throw new ArgumentException("Passing should be between 0 and 100.");

            }

            this.passing = value;


        }
    }
    public int Shooting
    {
        get
        {
            return this.shooting;
        }
    private    set
        {
            if (value < 0 || value > 100)
            {
                throw new ArgumentException("Shooting should be between 0 and 100.");


            }

            this.shooting = value;


        }
    }
    public int AveraStatsfPlayer()
    {
        return (int)Math.Round((this.endurance + spirit + dribble + passing + shooting) / 5.0);
    }
}
class Program
{
    static void Main()
    {


        string[] inputData = Console.ReadLine().Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries).ToArray();
        List<Team> teams = new List<Team>();
        while (inputData[0] != "END")
        {
            if (inputData[0] == "Team")
            {
                Team team = new Team(inputData[1]);

                teams.Add(team);
            }
            if (inputData[0] == "Add")
            {
                string name = inputData[2];
                int endurance = Convert.ToInt32(inputData[3]);
                int spirit = Convert.ToInt32(inputData[4]);
                int dribble = Convert.ToInt32(inputData[5]);
                int passing = Convert.ToInt32(inputData[6]);
                int shooting = Convert.ToInt32(inputData[7]);
                var team = teams.FirstOrDefault(t => t.Name == inputData[1]);
                bool teamExists = teams.Any(t => t.Name == inputData[1]);
                if (teamExists)
                {
                    try
                    {
                        Player player = new Player(name, endurance, spirit, dribble, passing, shooting);
                        team.AddPlayers(player);
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e.Message);

                    }
                }
                else
                {
                    Console.WriteLine("Team {0} does not exist.", inputData[1]);
                }


            }
            else if (inputData[0] == "Remove")
            {
                string teamName = inputData[1];
                string name = inputData[2];
                var team = teams.FirstOrDefault(t => t.Name == inputData[1]);
                try
                {

                    team.RemovePlayer(teamName, name);//?

                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                 
                }

            }
            else if (inputData[0] == "Rating")
            {
                var team = teams.FirstOrDefault(t => t.Name == inputData[1]);
                if (team != null)
                {
                    Console.WriteLine("{0} - {1}", team.Name, team.Rating());
                }

            }
            inputData = Console.ReadLine().Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries).ToArray();
        }
    }
}

