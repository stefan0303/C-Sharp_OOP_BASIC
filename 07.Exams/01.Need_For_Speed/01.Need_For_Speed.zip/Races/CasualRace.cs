﻿using System.Collections.Generic;

class CasualRace : Race
{

    public CasualRace(int length, string route, int prizePool)
        : base(length, route, prizePool)
    {
    }

    public void OverallPerformance(List<Car> cars)
    {

    }
}

