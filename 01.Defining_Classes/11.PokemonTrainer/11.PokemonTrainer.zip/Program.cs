﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;


class Program
{
    static void Main()
    {
        List<Trainer> trainers = new List<Trainer>();
        string[] input = Console.ReadLine().Split(' ').ToArray();
        while (input[0] != "Tournament")
        {
            string trainerName = input[0];
            string pockemonName = input[1];
            string pockemonElementh = input[2];
            int pockemonHealth = int.Parse(input[3]);

            var tra = trainers.Any(t => t.name == trainerName);
            if (!tra)//there is no trainer with that name we make new trainer
            {
                Trainer trainer = new Trainer(trainerName, 0, new List<Pokemon>());
                Pokemon pokemon = new Pokemon(pockemonName, pockemonElementh, pockemonHealth);
                trainer.pokemons.Add(pokemon);
                trainers.Add(trainer);
            }
            else//there is trainer in list of trainers
            {
                Pokemon pokemon = new Pokemon(pockemonName, pockemonElementh, pockemonHealth);
                trainers.FirstOrDefault(t => t.name == trainerName).pokemons.Add(pokemon);
            }
            input = Console.ReadLine().Split(' ').ToArray();
        }
        string command = Console.ReadLine();
        while (command != "End")
        {
            if (command=="Fire"||command== "Electricity"||command=="Water")
            {
                foreach (var tra in trainers)
                {
                    if (tra.pokemons.Any(p => p.element == command))
                    {
                        tra.badges += 1;
                    }
                    else
                    {
                        foreach (var pokemon in tra.pokemons)
                        {
                            pokemon.health -= 10;
                            if (pokemon.health <= 0)
                            {
                                tra.pokemons.Remove(pokemon);
                                break;
                            }
                        }
                    }
                }
            }
            command = Console.ReadLine();
        }
        var output = trainers.OrderByDescending(t => t.badges);
        foreach (var tra in output)
        {
            Console.WriteLine(tra.name +" "+tra.badges+" "+tra.pokemons.Count);
        }
    }
}


class Trainer
{
    public string name;
    public int badges;//start with 0
    public List<Pokemon> pokemons;

    public Trainer(string name, int badges, List<Pokemon> pokemons)
    {
        this.name = name;
        this.badges = badges;
        this.pokemons = pokemons;
    }


}

class Pokemon
{
    public string name;
    public string element;
    public int health;

    public Pokemon(string name, string element, int health)
    {
        this.name = name;
        this.element = element;
        this.health = health;
    }
}