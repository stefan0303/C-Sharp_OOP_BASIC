﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Parent
{
    private string name;
    private DateTime parentBirthDate;

    public DateTime ParentBirhDate { get; set; }
    public string Name { get; set; }
}

