﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    class Car
    {
        private string model;
        private double carSpeed;

        public double CarSpeed { get; set; }
        public string Model { get; set; }
    }

