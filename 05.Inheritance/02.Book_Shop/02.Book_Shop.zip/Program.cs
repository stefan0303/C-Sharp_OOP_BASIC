﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

 class Book
{
    private string author;
    private string title;
    private double price;
    public Book(string author, string title, double price)//razlichno v gotovia kod
    {
        this.Title = title;
        this.Author = author;
        this.Price = price;
    }
    public string Title
    {
        get
        {
            return this.title;
        }
        set
        {
            if (value.Length < 3)
            {
                throw new ArgumentException("Title not valid!");
            }
            this.title = value;
        }
    }
    public string Author
    {

        get
        {
            return this.author;
        }
        set
        {
            string[] valueNotValid = value.Split(new char[0],StringSplitOptions.RemoveEmptyEntries).ToArray();
            string number = valueNotValid[1].Substring(0, 1);
            string numbers = "0123456789";
            if (numbers.Contains(number))
            {
                throw new ArgumentException("Author not valid!");
            }
            this.author = value;
        }
    }
    public virtual double Price
    {
        get
        {
            return this.price;
        }
        set
        {
            if (value <= 0)
            {
                throw new ArgumentException("Price not valid!");
            }
            this.price = value;
        }
    }
    public override string ToString()
    {
        StringBuilder sb = new StringBuilder();
        sb.Append("Type: ").Append(this.GetType().Name)
                .Append(Environment.NewLine)
                .Append("Title: ").Append(this.Title)
                .Append(Environment.NewLine)
                .Append("Author: ").Append(this.Author)
                .Append(Environment.NewLine)
                .Append(String.Format("Price: {0:f1}", this.Price)) //!!!Sus string format izpisvam edin znak sled zapetaiata
                .Append(Environment.NewLine);

        return sb.ToString();
    }

}
 class GoldenEditionBook : Book
{
    public GoldenEditionBook(string author, string title, double price)
        : base(author, title, price)
    {

    }
    public override double Price//vij gotovia kod!
    {
        get
        {
            return base.Price * 1.3;
        }


    }
}
class Program
{
    static void Main()
    {
        try
        {
            string author = Console.ReadLine();
            string title = Console.ReadLine();
            double price = double.Parse(Console.ReadLine());

            Book book = new Book(author, title, price);
            GoldenEditionBook goldenEditionBook = new GoldenEditionBook(author, title, price);

            Console.WriteLine(book);
            Console.WriteLine(goldenEditionBook);
        }
        catch (ArgumentException ae)
        {
            Console.WriteLine(ae.Message);
        }

    }
}
