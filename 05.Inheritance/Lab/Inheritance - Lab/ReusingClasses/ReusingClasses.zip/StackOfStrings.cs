﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class StackOfStrings
{
    private List<string> data;

    public void Push(string item)
    {
        this.data.Add(item);
    }
    public string Pop()
    {
        return "";

    }
    public string Peek()
    {
        return "";

    }
    public bool IsEmpty()
    {
        return true;
    }
}

